//
//  SolToolboxApp.swift
//  SolToolbox
//
//  Created by Ramy on 6/12/21.
//

import SwiftUI

@main
struct SolToolboxApp: App {
    // Launch the ViewModel
    let PodViewModel = ViewModel()

    var body: some Scene {
        WindowGroup {
            // Launch the main view using a copy of the pods list (to protect the model) supplied by the ViewModel
            PodListView(viewModelListOfPods: PodViewModel.listOfSolsticePods)
        }
    }
}
