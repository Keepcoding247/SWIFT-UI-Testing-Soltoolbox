//
//  solsticeSessionDelegate.swift
//  SolToolbox
//
//  Created by Ramy Alam on 4/5/21.
//

//*************************************************************************************************
//** Delegate to reply to the security certificate challenge by the pod ***************************
//*************************************************************************************************

import Foundation

class solsticeSessionDelegate: NSObject, URLSessionDelegate{

   
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: (URLSession.AuthChallengeDisposition, URLCredential?) -> Void)
    {
        //let credentials =   URLCredential(user: APIKeys.kUsername.rawValue, password: APIKeys.kPassword.rawValue, persistence: NSURLCredentialPersistence.Permanent)
        let credentials =   URLCredential(user: "admin", password: "", persistence: URLCredential.Persistence.permanent)

        //completionHandler(URLSession.AuthChallengeDisposition.UseCredential, credentials)
        completionHandler(.useCredential, credentials)
        //print("task-didReceiveChallengeeeeeeeeee")

    }
    
    
    func URLSession(session: URLSession!, task: URLSessionTask!, didReceiveChallenge challenge: URLAuthenticationChallenge!, completionHandler: ((URLSession.AuthChallengeDisposition, URLCredential?) -> Void)!){
        
        print("task-didReceiveChallenge")
        
        completionHandler(.cancelAuthenticationChallenge, nil)
            return
    }
    
}
