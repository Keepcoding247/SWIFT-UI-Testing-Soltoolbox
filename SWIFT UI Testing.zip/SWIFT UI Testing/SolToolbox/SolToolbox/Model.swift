//
//  Model.swift
//  SolToolbox
//
//  Created by Ramy on 6/25/21.
//

import Foundation
import Network

//var talking: NWConnection?
var listening: NWListener?

var ModelSolsticePodList: [ModelSolsticePod] = DiscoverSolsticePods()

struct ModelSolsticePod {
    var podName: String = ""
    var podIPAddress: String = ""

    
    //*************************************************************************************************
    //** Reboot Pod ***********************************************************************************
    //*************************************************************************************************

    func rebootPod(_ podIPAddres: String, _ podPassword: String) {
        
        var done:Bool = false
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + podIPAddres + "/api/control/reboot?password=" + podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
               done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return
    }
 
    
    //*************************************************************************************************
    //** Reset the Pod Screen Key *********************************************************************
    //*************************************************************************************************

    func resetScreenKey(_ podIPAddres: String, _ podPassword: String) -> String {
        
        var ServerResponse:String = ""
        var done:Bool = false
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + podIPAddres + "/api/control/resetkey?password=" + podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "RESET SCREEN KEY  : FAILED"
                }
                done = true
            }
        }.resume()

        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
    }
    
    
    //*************************************************************************************************
    //** Boot All the Pod Posts ***********************************************************************
    //*************************************************************************************************
    
    func bootAllUsers(_ podIPAddres: String, _ podPassword: String) -> String {

        var ServerResponse:String = ""
        var done:Bool = false
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + podIPAddres + "/api/control/boot?password=" + podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "BOOT ALL USERS  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
    }
    
    
    //*************************************************************************************************
    //** Clear All the Pod Posts **********************************************************************
    //*************************************************************************************************
    
    func clearAllPosts(_ podIPAddres: String, _ podPassword: String)  -> String {
        
        var ServerResponse:String = ""
        var done:Bool = false
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + podIPAddres + "/api/control/clear?password=" + podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "CLEAR ALL POSTS  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
    }
    
    
    //*************************************************************************************************
    //** Set Custom Message ***************************************************************************
    //*************************************************************************************************

    func setCustomMessage(podIPAddress: String, podPassword: String, customMessage:String, RSSFeed:String) -> String {
    
        struct jsonStruct : Codable {
            var password: String
            var m_networkCuration: M_rssFeedList
        }
        
        struct M_rssFeedList: Codable {
            var m_rssFeedList: [M_message]
        }
        
        struct M_message: Codable {
            var enabled: Bool = false
            var name: String = ""
            var length: Int = 0
            var uri: String = ""
        }
 
        var podNewCustomMessage: M_message!
        var podNewRSSFeed: M_message!
        var ServerResponse:String = ""
        var done:Bool = false

        // If a message was sent then change the pod custom message, else reset it.
        if customMessage.count > 0 {
            podNewCustomMessage = M_message(enabled: true, name: "Custom Message", length: 0, uri: customMessage);
        } else {
            podNewCustomMessage = M_message(enabled: false, name: "Custom Message", length: 0, uri: "");
        }
        
        // If an RSS Feed was sent then change the pod RSS Feed, else reset it.
        if (RSSFeed.count) > 0 {
            podNewRSSFeed = M_message(enabled: true, name: RSSFeed, length: 3, uri: RSSFeed);
        } else {
            podNewRSSFeed = M_message(enabled: false, name: "", length: 0, uri:"");
        }
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + podIPAddress + "/api/config?password=" + podPassword)!)
        myRequest.httpMethod = "POST"
        myRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Pack the new custom message and RSS Feed in a JSON structure
        let podNewRSSFeedList = M_rssFeedList(m_rssFeedList: [podNewCustomMessage, podNewRSSFeed])
        let jsonData = jsonStruct(password: podPassword, m_networkCuration: podNewRSSFeedList)

        do {
            let jsonEncoder = JSONEncoder()
            let myjsonData = try jsonEncoder.encode(jsonData)
            myRequest.httpBody = myjsonData
        } catch {
            print("Unexpected error: \(error).")
        }

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "CLEAR ALL POSTS  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
        
    }

  
    //*************************************************************************************************
    //** Set Emergency Message ************************************************************************
    //*************************************************************************************************

    func setEmergencyMessage(podIPAddress: String, podPassword: String, emergencyMessage: String) -> String {
    
        struct jsonStruct : Codable {
            var password: String
            var m_networkCuration: M_Emergency_message
        }
        
        struct M_Emergency_message: Codable {
            var emergencyEnabled: Bool = false
            var emergencyText: String = ""
        }
 
        var myEmergencyMessage: M_Emergency_message!
        var ServerResponse:String = ""
        var done:Bool = false

        // If a message was sent then change the pod Emergency message, else reset it.
        if emergencyMessage.count > 0 {
            myEmergencyMessage = M_Emergency_message(emergencyEnabled: true, emergencyText: emergencyMessage);
        } else {
            myEmergencyMessage = M_Emergency_message(emergencyEnabled: false, emergencyText: "");
        }
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + podIPAddress + "/api/config?password=" + podPassword)!)
        myRequest.httpMethod = "POST"
        myRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Pack the new custom message and RSS Feed in a JSON structure
        let jsonData = jsonStruct(password: podPassword, m_networkCuration: myEmergencyMessage)

        do {
            let jsonEncoder = JSONEncoder()
            let myjsonData = try jsonEncoder.encode(jsonData)
            myRequest.httpBody = myjsonData
        } catch {
            print("Unexpected error: \(error).")
        }

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "CLEAR ALL POSTS  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
        
    }


//*************************************************************************************************
//** Set pod name  ********************************************************************************
//*************************************************************************************************

func setDisplayName(podIPAddress: String, podPassword: String, newDisplayName: String) -> String {
    
    // If a message was sent then change the pod custom message, else reset it.
    if newDisplayName.count > 0 {

        struct jsonStruct : Codable {
            var password: String
            var m_displayInformation: M_displayName
        }
        
        struct M_displayName: Codable {
            var m_displayName: String
        }
        
    
        var ServerResponse:String = ""
        var done:Bool = false

            
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + podIPAddress + "/api/config?password=" + podPassword)!)
        myRequest.httpMethod = "POST"
        myRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Pack the new custom message and RSS Feed in a JSON structure
        let displayName = M_displayName(m_displayName: newDisplayName);
        let jsonData = jsonStruct(password: podPassword, m_displayInformation: displayName)

        do {
            let jsonEncoder = JSONEncoder()
            let myjsonData = try jsonEncoder.encode(jsonData)
            myRequest.httpBody = myjsonData
        } catch {
            print("Unexpected error: \(error).")
        }

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "SET POD NAME  : FAILED"
                }
                done = true
            }
        }.resume()

        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the reply.
        return ServerResponse
    } else {
        return "NO POD NAME TO CHANGE"
    }
}
}


//*************************************************************************************************
//** Discover any pods broadcasting on the network  ***********************************************
//*************************************************************************************************
func DiscoverSolsticePods() -> [ModelSolsticePod] {
    var discoveredSolsticePodList = [ModelSolsticePod]()
    var discoveredSolsticePod = ModelSolsticePod()

    do {
        //Create a UDP NWListener listener to listen for pod boadcast on port 55001
        // a TRY is needed to catch any errors
        listening = try NWListener(using: .udp, on: 55001)
        //This is the handler to manage the result of the cretion of the listener
        listening?.stateUpdateHandler = {(newState) in
            switch newState {
                case .ready:
                    print("\n\nready\n\n")
                default:
                    break
            }
        }
        
        // This is the handler what to do if a new pod broadcast is detected
        listening?.newConnectionHandler = {(newConnection) in
            newConnection.stateUpdateHandler = {newState in
                switch newState {
                
                    // if the status of the new connection is READY
                    case .ready:
                        
                        print("new connection")
                        // grab the new message sent by the disovered pod
                        newConnection.receiveMessage { (data, context, isComplete, error) in
                        if let error = error {
                            print(error)
                        } else if let data = data, !data.isEmpty {
                            // We hav a valid pod broadcast message
                            // Decode the pod broadcast message
                            let podBroadcastInfo = String(decoding: data, as: UTF8.self)
                            print(podBroadcastInfo)
                      
                            // Split the pod broadcast ingo into an array of info
                            let podInfoArray = podBroadcastInfo.split(whereSeparator: {$0 == "-"})
                            
                            // The pod name in [8] with some additional string starting with newline
                            // Split the name and take the first part
                            let podNameArray = podInfoArray[8].split(whereSeparator: {$0 == "\n"})

                            // Extract the discovered pod Name
                            let podName = String(podNameArray[0])
                            //self.discoveredPodNameList.append(podName)

                            // Extract the discovered pod IP Address
                            let decimalPodIPAddressString = decodePodIPAddress(podIPAddressString: String(podInfoArray[5]))
                            let stringPodIPAddressString = String(decimalPodIPAddressString)
                            
                            // Create a new discovered pod structure
                            discoveredSolsticePod.podName = podName
                            discoveredSolsticePod.podIPAddress = stringPodIPAddressString
                            discoveredSolsticePodList.append(discoveredSolsticePod)
                        }
                        }
                    
                    default:
                        break
                    }
            }
            // Start the new connection handler
            //newConnection.start(queue: DispatchQueue(label: "new client"))
            newConnection.start(queue: .main)
        }
    } catch {
        // Cacth the TRY that failed to create a UDP listener
        print("unable to create listener")
    }
    listening?.start(queue: .main)

    // Wait for the URL session call to return
    RunLoop.current.run(until: Date(timeIntervalSinceNow: 5.0))
    
    return discoveredSolsticePodList
}


//*************************************************************************************************
//** Decode the pod IP Address from the received pod brodcast  ************************************
//*************************************************************************************************
func decodePodIPAddress(podIPAddressString:String) -> String {
    let podIPAddressArray = podIPAddressString.map({ String($0) })
    
    let part1Hex = podIPAddressArray[0] + podIPAddressArray[1]
    let part1Dec = Int(part1Hex, radix: 16)!
    
    let part2Hex = podIPAddressArray[2] + podIPAddressArray[3]
    let part2Dec = Int(part2Hex, radix: 16)!
    
    let part3Hex = podIPAddressArray[4] + podIPAddressArray[5]
    let part3Dec = Int(part3Hex, radix: 16)!
    
    let part4Hex = podIPAddressArray[6] + podIPAddressArray[7]
    let part4Dec = Int(part4Hex, radix: 16)!
    
    let decimalPodIPAddressString = String(part1Dec) + "." + String(part2Dec) + "." + String(part3Dec) + "." + String(part4Dec)

    return decimalPodIPAddressString
}



//*************************************************************************************************
//** Retrieve the Pod Number of Connected Users ***************************************************
//*************************************************************************************************

func getConnectedUsers(_ podIPAddres: String, _ podPassword: String) -> Int {
//        var podToken: String = getToken(podIPAddres, podPassword)

    struct ServerResponse : Codable {
        var m_displayId: String
        var m_serverVersion: String
        var m_displayInformation: M_displayInformation
        var m_statistics: M_statistics
    }

    struct M_displayInformation : Codable {
        var m_displayName: String
        var m_productName: String
        var m_productVariant: String
        var m_productHardwareVersion: Int
    }

    struct M_statistics : Codable {
        var m_currentPostCount: Int
        var m_currentBandwidth: Int
        var m_currentLiveSourceCount: Int
        var m_connectedUsers: Int
        var m_timeSinceLastConnectionInitialize: Int
    }

    var done:Bool = false
    var connected_Users:Int = 0

    // Create the Request URL
    var myRequest = URLRequest(url: URL(string: "https://" + podIPAddres + "/api/stats?password=" + podPassword)!)
    myRequest.httpMethod = "GET"

    // Assign a Delegate to reply to the security certificate challenge by the pod
    let sessionDelegate = solsticeSessionDelegate()

    // Create the URL Session
    let sessionConfig = URLSessionConfiguration.default
    let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.current)

    session.dataTask(with: myRequest) { (data, response, error) in
        do {
            let response = try JSONDecoder().decode(ServerResponse.self, from: data!)
            connected_Users = response.m_statistics.m_connectedUsers
            done = true
        } catch {
            print(error)
            done = true
        }
    }.resume()

    // Wait for the URL session call to return
    repeat {
        RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
    } while !done

    // The session returned so now we can return the wifi info.
    return connected_Users
}

//*************************************************************************************************
//** Retrieve the Pod Token ***********************************************************************
//*************************************************************************************************

func getToken(_ podIPAddres: String, _ podPassword: String)  -> String {
    struct ServerResponse : Codable {
        var access_token: String
        var token_type: String
    }

    var done:Bool = false
    var podToken: String = ""

    // Create the Request Header
    let requestHeader = [
        "Authorization" : "",
        "Content-Type" : "application/x-www-form-urlencoded",
        "Accept" : "application/json"
    ]

    // Create the Request Body
    var requestsBodyComponents = URLComponents()
    requestsBodyComponents.queryItems = [URLQueryItem(name: "grant_type", value: "password"), URLQueryItem(name: "username", value: "admin"), URLQueryItem(name: "password", value: podPassword)]

    // Create the Request URL
    var myRequest = URLRequest(url: URL(string: "https://" + podIPAddres + ":5443/v2/token")!)
    myRequest.httpMethod = "POST"
    myRequest.allHTTPHeaderFields = requestHeader
    myRequest.httpBody = requestsBodyComponents.query?.data(using: .utf8)

    // Assign a Delegate to reply to the security certificate challenge by the pod
    let sessionDelegate = solsticeSessionDelegate()

    // Create the URL Session
    let sessionConfig = URLSessionConfiguration.default
    let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.current)

    session.dataTask(with: myRequest) { (data, response, error) in
        do {
            let response = try JSONDecoder().decode(ServerResponse.self, from: data!)
            podToken = response.access_token
            done = true
        } catch {
            print(error)
            podToken = "Sorry! I can't retrieve the pod's token"
            done = true
        }
    }.resume()

    // Wait for the URL session call to return
    repeat {
        RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
    } while !done

    // The session returned so now we can return the token.
    return podToken
}






let testdata = [
    ModelSolsticePod(podName: "SolsticePod1", podIPAddress: "192.168.53.1")
]
