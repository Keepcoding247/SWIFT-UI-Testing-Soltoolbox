//
//  ManageSolsticePodView.swift
//  SolToolbox
//
//  Created by Ramy on 6/12/21.
//

import SwiftUI

struct ManageSolsticePodView: View {
    var viewModelPod: ModelSolsticePod

    var body: some View {
        TabView {
            PodControlSubview(viewModelPod: viewModelPod)
                .tabItem {Label("Control", systemImage: "switch.2")
                }
            PodSettingsSubview(viewModelPod: viewModelPod)
                .tabItem {Label("Settings", systemImage: "gear")
                }
            PodCalendarSubview(viewModelPod: viewModelPod)
                .tabItem {Label("Calendar", systemImage: "calendar")
                }
            PodMessageSubview(viewModelPod: viewModelPod)
                .tabItem {Label("Messages", systemImage: "message")
                }
            PodControlSubview(viewModelPod: viewModelPod)
                .tabItem {Label("Splashscreen", systemImage: "display")
                }
        }
    }
}

//***************************************************************
//***************************************************************
//***************************************************************


struct PodControlSubview: View {
    var viewModelPod: ModelSolsticePod
    var body: some View {
        VStack {
            DisplaySubview(viewModelPod: viewModelPod)
            Spacer()
            Spacer()
            HStack {
                RebootPodButton(viewModelPod: viewModelPod)
                ResetScreenKeyButton(viewModelPod: viewModelPod)
            }
            Spacer()
            Spacer()
            HStack {
                ClearAllPostsButton(viewModelPod: viewModelPod)
                BootAllUsersButton(viewModelPod: viewModelPod)
            }
            Spacer()
            Spacer()
        }
            .padding(.horizontal)
//        .background(Color.gray.opacity(0.3))
    }
}


struct DisplaySubview: View {
    var viewModelPod: ModelSolsticePod
    var body: some View {

        ZStack {
            Image(systemName: "tv")
                .resizable(resizingMode: .tile)
//                .aspectRatio(contentMode: .fit)
                .foregroundColor(Color.secondary)
            //.navigationTitle(pod.podName)
            VStack {
                Text(viewModelPod.podName)
                    .font(.title)
                Text(viewModelPod.podIPAddress)
                    .font(.title2)
            }
                .foregroundColor(.green)
                .padding(.all)
        }
    }
}


struct RebootPodButton: View {
    var viewModelPod: ModelSolsticePod
    var body: some View {
        GreenButton(systemPictureName: "arrow.triangle.2.circlepath")
            .onLongPressGesture(perform: {
                viewModelPod.rebootPod(viewModelPod.podIPAddress, "")
        })
    }
}


struct ResetScreenKeyButton: View {
    var viewModelPod: ModelSolsticePod
    var body: some View {
        GreenButton(systemPictureName: "textformat.123")
            .onLongPressGesture(perform: {
                _ = viewModelPod.resetScreenKey(viewModelPod.podIPAddress, "")
            })
    }
}


struct ClearAllPostsButton: View {
    var viewModelPod: ModelSolsticePod
    var body: some View {
        GreenButton(systemPictureName: "clear")
            .onLongPressGesture(perform: {
                _ = viewModelPod.clearAllPosts(viewModelPod.podIPAddress, "")
        })
    }
}


struct BootAllUsersButton: View {
    var viewModelPod: ModelSolsticePod
    var body: some View {
        GreenButton(systemPictureName: "person.fill.xmark")
            .onLongPressGesture(perform: {
                _ = viewModelPod.bootAllUsers(viewModelPod.podIPAddress, "")
        })
    }
}


//***************************************************************
//***************************************************************
//***************************************************************

struct PodMessageSubview: View {
    @State private var welcomeMessage: String = ""
    @State private var emergencyMessage: String = ""

    var viewModelPod: ModelSolsticePod
    var body: some View {
        VStack{
            TextField("Enter Welcome Message", text: $welcomeMessage)
                .font(Font.system(size: 30))
                .multilineTextAlignment(.center)
                .background(Color.gray.opacity(0.5))
                .cornerRadius(25, antialiased: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
            Spacer()
            SetWelcomeMessage(viewModelPod: viewModelPod, welcomeMessage: welcomeMessage)
            Spacer()
            Spacer()
            Spacer()
            TextField("Enter Emergency Message", text: $emergencyMessage)
                .font(Font.system(size: 30))
                .multilineTextAlignment(.center)
                .background(Color.gray.opacity(0.5))
                .cornerRadius(25, antialiased: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
            Spacer()
            SetEmergencyMessage(viewModelPod: viewModelPod, emergemcyMessage: emergencyMessage)
            Spacer()
        } .padding(.all)
    }
}


struct SetWelcomeMessage: View {
    var viewModelPod: ModelSolsticePod
    var welcomeMessage: String
    var body: some View {
        SmallGreenButton(systemPictureName: "text.bubble")
            .onLongPressGesture(perform: {
                _ = viewModelPod.setCustomMessage(podIPAddress: viewModelPod.podIPAddress, podPassword: "", customMessage: welcomeMessage, RSSFeed: "")
            })
    }
}


struct SetEmergencyMessage: View {
    var viewModelPod: ModelSolsticePod
    var emergemcyMessage: String
    var body: some View {
        SmallRedButton(systemPictureName: "text.bubble")
            .onLongPressGesture(perform: {
                _ = viewModelPod.setEmergencyMessage(podIPAddress: viewModelPod.podIPAddress, podPassword: "", emergencyMessage: emergemcyMessage)
            })
    }
}


//***************************************************************
//***************************************************************
//***************************************************************

struct PodSettingsSubview: View {
    @State private var displayName: String = ""

    var viewModelPod: ModelSolsticePod
    var body: some View {
        VStack{
            Spacer()
            TextField("Enter New Display Name", text: $displayName)
                .font(Font.system(size: 30))
                .multilineTextAlignment(.center)
                .background(Color.gray.opacity(0.5))
                .cornerRadius(25, antialiased: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/)
            Spacer()
            SetDisplayName(viewModelPod: viewModelPod, displayName: displayName)
            Spacer()
        } .padding(.all)
    }
}


struct SetDisplayName: View {
    var viewModelPod: ModelSolsticePod
    var displayName: String
    var body: some View {
        SmallGreenButton(systemPictureName: "text.bubble")
            .onLongPressGesture(perform: {
                _ = viewModelPod.setDisplayName(podIPAddress: viewModelPod.podIPAddress, podPassword: "", newDisplayName: displayName)
            })
    }
}


//***************************************************************
//***************************************************************
//***************************************************************

struct PodCalendarSubview: View {
    @State private var meetingstartTime = 0.0
    @State private var meetingStartTimeString = ""
    
    var viewModelPod: ModelSolsticePod
    var body: some View {
        let sliderStartTime = GetSliderStartTime()
        let sliderEndTime = GetSliderEndTime()

        VStack {
            Spacer()
            Text("Select Meeting Time")
            Slider(
                value: $meetingstartTime,
                in: sliderStartTime...sliderEndTime,
                step: 15,
                onEditingChanged: { editing in
                    meetingStartTimeString = FormatSliderStartTime(meetingstartTime)
                }
            ) .accentColor(.green).padding()
            Text(meetingStartTimeString)
            Spacer()
            Spacer()
            Spacer()
        }
    }
}


func GetSliderStartTime() -> Double {
//    return Date().timeIntervalSince1970
    let nowHour = Double(Calendar.current.component(.hour, from: Date()))
    let nowMinutes = Calendar.current.component(.minute, from: Date())
    let nextMeetingStartMinutes:Double = Double(((Int(nowMinutes/15)+1)*15))
    let sliderStartTimeMinutes:Double = Double(nowHour * 60 + nextMeetingStartMinutes)
    return sliderStartTimeMinutes
}


func GetSliderEndTime() -> Double {
    let sliderEndTimeMinutes:Double = 23 * 60 + 30
    return sliderEndTimeMinutes
}
    

func FormatSliderStartTime(_ meetingstartTime:Double) -> String {
    let startTimeHours = Int(meetingstartTime/60)
    let startTimeMinutes = Int(meetingstartTime) - startTimeHours * 60
    let startTimeString = String(format: "%.2i:%.2d", startTimeHours, startTimeMinutes)
    return startTimeString
}


//***************************************************************
//***************************************************************
//***************************************************************

struct GreenButton: View {
    var systemPictureName: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                .aspectRatio(CGSize(width: 4, height: 4), contentMode: .fill)
                .foregroundColor(.green)
                .shadow(color: /*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/, radius: 3, x: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/, y: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/)
            Image(systemName: systemPictureName)
                .resizable(resizingMode: .tile)
                .aspectRatio(contentMode: .fit)
                .foregroundColor(Color.white)
                .padding(.all)
        }
    }
}


struct SmallGreenButton: View {
    var systemPictureName: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                .aspectRatio(CGSize(width: 4, height: 4), contentMode: .fit)
                .foregroundColor(.green)
                .shadow(color: /*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/, radius: 3, x: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/, y: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/)
            Image(systemName: systemPictureName)
                .resizable(resizingMode: .tile)
                .aspectRatio(contentMode: .fit)
                .foregroundColor(Color.white)
                .padding(.all)
        }
    }
}


struct SmallRedButton: View {
    var systemPictureName: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
//                .frame(width: 200, height: 170)
                .aspectRatio(CGSize(width: 4, height: 4), contentMode: .fit)
                .foregroundColor(.red)
                .shadow(color: /*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/, radius: 3, x: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/, y: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/)
            Image(systemName: systemPictureName)
                .resizable(resizingMode: .tile)
                .aspectRatio(contentMode: .fit)
                .foregroundColor(Color.white)
                .padding(.all)
        }
    }
}





//***************************************************************
//***************************************************************
//***************************************************************


struct SolsticePodDetails_Previews: PreviewProvider {
    static var previews: some View {
        ManageSolsticePodView(viewModelPod: testdata[0])
        ManageSolsticePodView(viewModelPod: testdata[0]) .colorScheme(.dark)
    }
}

