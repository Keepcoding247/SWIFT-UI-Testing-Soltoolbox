//
//  SolsticePodClass.swift
//  SolToolbox
//
//  Created by Ramy Alam on 4/5/21.
//

import Foundation

 
class SolsticePod {
    
    var podIPAddres: String = ""
    var podPassword: String = ""
    var podToken: String = ""

    init(podIPAddres: String, podPassword: String) {
        self.podIPAddres = podIPAddres
        self.podPassword = podPassword
    }
    
   
    
    //*************************************************************************************************
    //** Retrieve the Pod Token ***********************************************************************
    //*************************************************************************************************
    
    func getToken() -> String {
        struct ServerResponse : Codable {
            var access_token: String
            var token_type: String
        }
        
        var done:Bool = false

        // Create the Request Header
        let requestHeader = [
            "Authorization" : "",
            "Content-Type" : "application/x-www-form-urlencoded",
            "Accept" : "application/json"
        ]

        // Create the Request Body
        var requestsBodyComponents = URLComponents()
        requestsBodyComponents.queryItems = [URLQueryItem(name: "grant_type", value: "password"), URLQueryItem(name: "username", value: "admin"), URLQueryItem(name: "password", value: self.podPassword)]
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + ":5443/v2/token")!)
        myRequest.httpMethod = "POST"
        myRequest.allHTTPHeaderFields = requestHeader
        myRequest.httpBody = requestsBodyComponents.query?.data(using: .utf8)
        
        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                let response = try JSONDecoder().decode(ServerResponse.self, from: data!)
                self.podToken = response.access_token
                done = true
            } catch {
                print(error)
                self.podToken = "Sorry! I can't retrieve the pod's token"
                done = true
            }
        }.resume()
        
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the token.
        return self.podToken
    }
    
    
    //*************************************************************************************************
    //** Retrieve the Pod Wifi Signal Quality *********************************************************
    //*************************************************************************************************
    
    func getWifiSignalQuality() -> String {
        
        struct ServerResponse : Codable {
            var connection: Connection
        }
        
        struct Connection : Codable {
            var wifi: Wifi
        }
        
        struct Wifi : Codable {
            var dns1: String
            var dns2: String
            var gateway: String
            var hostname: String
            var ip_address: String
            var ip_type: String
            var mac_address: String
            var wifi_signal: Wifi_signal
        }

        struct Wifi_signal : Codable {
            var signal_quality: String
            var signal_strength: Int
            var signal_units: String
        }

        var done:Bool = false
        var wifi_signal_quality:String = "Unknown"
        //var wifi_signal_strength:Int = 0
        //var wifi_signal_units:String = "Unknown"
        
        // Create the Request Header
        let requestHeader = [
            "accept": "application/json",
            "Authorization": "Bearer " + self.podToken
        ]
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + ":5443/v2/info/wifi")!)
        myRequest.httpMethod = "GET"
        myRequest.allHTTPHeaderFields = requestHeader
 
        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                let response = try JSONDecoder().decode(ServerResponse.self, from: data!)
                wifi_signal_quality = response.connection.wifi.wifi_signal.signal_quality
                //wifi_signal_strength = response.wifi.signal_strength
                //wifi_signal_units = response.wifi.signal_units
                done = true
            } catch {
                print(error)
                self.podToken = "Sorry! I can't retrieve the wifi info"
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return wifi_signal_quality
    }
    
    
    //*************************************************************************************************
    //** Retrieve the Pod Current Post Count **********************************************************
    //*************************************************************************************************
    
    func getCurrentPostCount() -> Int {
        
        struct ServerResponse : Codable {
            var m_displayId: String
            var m_serverVersion: String
            var m_displayInformation: M_displayInformation
            var m_statistics: M_statistics
        }
        
        struct M_displayInformation : Codable {
            var m_displayName: String
            var m_productName: String
            var m_productVariant: String
            var m_productHardwareVersion: Int
        }
        
        struct M_statistics : Codable {
            var m_currentPostCount: Int
            var m_currentBandwidth: Int
            var m_currentLiveSourceCount: Int
            var m_connectedUsers: Int
            var m_timeSinceLastConnectionInitialize: Int
        }

        var done:Bool = false
        var current_Post_Count:Int = 0
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + "/api/stats?password=" + self.podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                let response = try JSONDecoder().decode(ServerResponse.self, from: data!)
                current_Post_Count = response.m_statistics.m_currentPostCount
                done = true
            } catch {
                print(error)
                self.podToken = "Sorry! I can't retrieve the current post count"
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return current_Post_Count
    }
   
    
    //*************************************************************************************************
    //** Retrieve the Pod Number of Connected Users ***************************************************
    //*************************************************************************************************
    
    func getConnectedUsers() -> Int {
        
        struct ServerResponse : Codable {
            var m_displayId: String
            var m_serverVersion: String
            var m_displayInformation: M_displayInformation
            var m_statistics: M_statistics
        }
        
        struct M_displayInformation : Codable {
            var m_displayName: String
            var m_productName: String
            var m_productVariant: String
            var m_productHardwareVersion: Int
        }
        
        struct M_statistics : Codable {
            var m_currentPostCount: Int
            var m_currentBandwidth: Int
            var m_currentLiveSourceCount: Int
            var m_connectedUsers: Int
            var m_timeSinceLastConnectionInitialize: Int
        }

        var done:Bool = false
        var connected_Users:Int = 0
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + "/api/stats?password=" + self.podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                let response = try JSONDecoder().decode(ServerResponse.self, from: data!)
                connected_Users = response.m_statistics.m_connectedUsers
                done = true
            } catch {
                print(error)
                self.podToken = "Sorry! I can't retrieve the current post count"
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return connected_Users
    }
    
    
    
    //*************************************************************************************************
    //** Reset the Pod Screen Key *********************************************************************
    //*************************************************************************************************
    
    func resetScreenKey() -> String {
        
        var ServerResponse:String = ""
        var done:Bool = false
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + "/api/control/resetkey?password=" + self.podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "RESET SCREEN KEY  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
    }
    
    
    
    //*************************************************************************************************
    //** Clear All the Pod Posts **********************************************************************
    //*************************************************************************************************
    
    func clearAllPosts() -> String {
        
        var ServerResponse:String = ""
        var done:Bool = false
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + "/api/control/clear?password=" + self.podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "CLEAR ALL POSTS  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
    }
    
    
    //*************************************************************************************************
    //** Boot All the Pod Posts ***********************************************************************
    //*************************************************************************************************
    
    func bootAllUsers() -> String {

        var ServerResponse:String = ""
        var done:Bool = false
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + "/api/control/boot?password=" + self.podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "BOOT ALL USERS  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
    }
    
    
    //*************************************************************************************************
    //** Reboot Pod ***********************************************************************************
    //*************************************************************************************************

    func rebootPod() {
        
        var done:Bool = false
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + "/api/control/reboot?password=" + self.podPassword)!)
        myRequest.httpMethod = "GET"

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
               done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return
    }
    
    
    //*************************************************************************************************
    //** Set Custom Message ***************************************************************************
    //*************************************************************************************************

    func setCustomMessage(customMessage:String, RSSFeed:String) -> String {
    
        struct jsonStruct : Codable {
            var password: String
            var m_networkCuration: M_rssFeedList
        }
        
        struct M_rssFeedList: Codable {
            var m_rssFeedList: [M_message]
        }
        
        struct M_message: Codable {
            var enabled: Bool = false
            var name: String = ""
            var length: Int = 0
            var uri: String = ""
        }
 
        var podNewCustomMessage: M_message!
        var podNewRSSFeed: M_message!
        var ServerResponse:String = ""
        var done:Bool = false

        // If a message was sent then change the pod custom message, else reset it.
        if customMessage.count > 0 {
            podNewCustomMessage = M_message(enabled: true, name: "Custom Message", length: 0, uri: customMessage);
        } else {
            podNewCustomMessage = M_message(enabled: false, name: "Custom Message", length: 0, uri: "");
        }
        
        // If an RSS Feed was sent then change the pod RSS Feed, else reset it.
        if (RSSFeed.count) > 0 {
            podNewRSSFeed = M_message(enabled: true, name: RSSFeed, length: 3, uri: RSSFeed);
        } else {
            podNewRSSFeed = M_message(enabled: false, name: "", length: 0, uri:"");
        }
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + "/api/config?password=" + self.podPassword)!)
        myRequest.httpMethod = "POST"
        myRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Pack the new custom message and RSS Feed in a JSON structure
        let podNewRSSFeedList = M_rssFeedList(m_rssFeedList: [podNewCustomMessage, podNewRSSFeed])
        let jsonData = jsonStruct(password: self.podPassword, m_networkCuration: podNewRSSFeedList)

        do {
            let jsonEncoder = JSONEncoder()
            let myjsonData = try jsonEncoder.encode(jsonData)
            myRequest.httpBody = myjsonData
        } catch {
            print("Unexpected error: \(error).")
        }

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "CLEAR ALL POSTS  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
        
    }

  
    //*************************************************************************************************
    //** Set Emergency Message ************************************************************************
    //*************************************************************************************************

    func setEmergencyMessage(emergencyMessage:String) -> String {
    
        struct jsonStruct : Codable {
            var password: String
            var m_networkCuration: M_Emergency_message
        }
        
        struct M_Emergency_message: Codable {
            var emergencyEnabled: Bool = false
            var emergencyText: String = ""
        }
 
        var myEmergencyMessage: M_Emergency_message!
        var ServerResponse:String = ""
        var done:Bool = false

        // If a message was sent then change the pod Emergency message, else reset it.
        if emergencyMessage.count > 0 {
            myEmergencyMessage = M_Emergency_message(emergencyEnabled: true, emergencyText: emergencyMessage);
        } else {
            myEmergencyMessage = M_Emergency_message(emergencyEnabled: false, emergencyText: "");
        }
        
        // Create the Request URL
        var myRequest = URLRequest(url: URL(string: "https://" + self.podIPAddres + "/api/config?password=" + self.podPassword)!)
        myRequest.httpMethod = "POST"
        myRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Pack the new custom message and RSS Feed in a JSON structure
        let jsonData = jsonStruct(password: self.podPassword, m_networkCuration: myEmergencyMessage)

        do {
            let jsonEncoder = JSONEncoder()
            let myjsonData = try jsonEncoder.encode(jsonData)
            myRequest.httpBody = myjsonData
        } catch {
            print("Unexpected error: \(error).")
        }

        // Assign a Delegate to reply to the security certificate challenge by the pod
        let sessionDelegate = solsticeSessionDelegate()
        
        // Create the URL Session
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: sessionDelegate, delegateQueue: OperationQueue.main)

        session.dataTask(with: myRequest) { (data, response, error) in
            do {
                if let response = String(data: data!, encoding: .utf8) {
                    ServerResponse = response
                } else {
                    ServerResponse = "CLEAR ALL POSTS  : FAILED"
                }
                done = true
            }
        }.resume()
  
        // Wait for the URL session call to return
        repeat {
            RunLoop.current.run(until: Date(timeIntervalSinceNow: 0.1))
        } while !done

        // The session returned so now we can return the wifi info.
        return ServerResponse
        
    }

}

