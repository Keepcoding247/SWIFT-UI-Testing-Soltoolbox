//
//  PodListView.swift
//  SolToolbox
//
//  Created by Ramy on 6/12/21.
//

import SwiftUI

struct PodListView: View {
    var viewModelListOfPods: [ModelSolsticePod]

    var body: some View {
        NavigationView {
            List {
                ForEach(viewModelListOfPods, id: \.podIPAddress) { pod in
                    PodCell(viewModelPod: pod)
                }
                HStack {
                    Spacer()
                    Text("\(viewModelListOfPods.count) Pods")
                        .foregroundColor(.secondary)
                    Spacer()
                }
            }
            .navigationTitle("Solstice Pods")
            .foregroundColor(.green)
        }
    }
}   

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        PodListView(viewModelListOfPods: testdata)
    }
}

struct PodCell: View {
    var viewModelPod: ModelSolsticePod
    var body: some View {
        NavigationLink(destination: ManageSolsticePodView(viewModelPod: viewModelPod)) {
            Image(systemName: "display")
            VStack(alignment: .leading) {
                Text(viewModelPod.podName)
                    .font(.headline)
                Text(viewModelPod.podIPAddress)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
//            .background(Color.gray.opacity(0.3))
    }
}

