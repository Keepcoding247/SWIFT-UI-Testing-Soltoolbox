//
//  ViewModel.swift
//  SolToolbox
//
//  Created by Ramy on 6/20/21.
//

import Foundation

class ViewModel {
    // Protect the Model from the Views by making it Private. Only the ModelView can see and modify it
    private var modelSolsticePods: [ModelSolsticePod] = DiscoverSolsticePods()
    
    // Offer visibility of the Model to the Views by replicating it
    var listOfSolsticePods:[ModelSolsticePod] {
        return modelSolsticePods
    }

}
